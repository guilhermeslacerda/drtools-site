@echo off
java -jar %~dp0smell-churn.jar %*